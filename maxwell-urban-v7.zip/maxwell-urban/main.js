/* Maxwell Urban Contracting — interactions (shared by every page) */
(() => {
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const root = document.documentElement;
  const body = document.body;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finePointer = matchMedia("(hover: hover) and (pointer: fine)").matches;

  $$("[data-year]").forEach((el) => (el.textContent = new Date().getFullYear()));

  // Without the animation libraries, just show the page.
  if (!window.gsap || !window.ScrollTrigger) {
    root.classList.remove("js", "arriving");
    return;
  }
  window.__muStarted = true;
  gsap.registerPlugin(ScrollTrigger);
  // motion always plays; clear any choice saved by an older version of the site
  const motionPaused = false;
  try { localStorage.removeItem("mu-motion"); } catch (err) { /* storage blocked */ }

  // one feature failing (an odd browser, a missing element) must never freeze the page
  const safe = (name, fn) => { try { fn(); } catch (err) { console.error("[maxwell] " + name, err); } };

  /* ---------- Split words for the line reveals ---------- */
  function splitWords(el) {
    const walk = (node) => {
      [...node.childNodes].forEach((n) => {
        if (n.nodeType === 3) {
          const frag = document.createDocumentFragment();
          n.textContent.split(/(\s+)/).forEach((part) => {
            if (!part) return;
            if (/^\s+$/.test(part)) return frag.append(" ");
            const w = document.createElement("span");
            w.className = "w";
            const i = document.createElement("span");
            i.textContent = part;
            w.append(i);
            frag.append(w);
          });
          n.replaceWith(frag);
        } else if (n.nodeType === 1) walk(n);
      });
    };
    walk(el);
  }
  $$(".split").forEach(splitWords);

  // scroll-filled paragraphs: one span per word
  $$("[data-words]").forEach((p) => {
    p.innerHTML = p.innerHTML.trim().replace(/(<em>.*?<\/em>|[^\s<]+)/g, '<span class="word">$1</span>');
  });

  /* ---------- Smooth scroll ---------- */
  let lenis = null;
  if (!reduce && window.Lenis) {
    lenis = new Lenis({ lerp: 0.1 });
    lenis.on("scroll", ScrollTrigger.update);
    gsap.ticker.add((t) => lenis.raf(t * 1000));
    gsap.ticker.lagSmoothing(0);
  }
  // used by the quote form to bring its thank-you note into view below the header
  window.__muScrollTo = (el) => (lenis ? lenis.scrollTo(el, { duration: 1.1, force: true, offset: -110 }) : window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 110, behavior: "smooth" }));
  const scrollTo = (target, immediate = false) => {
    const el = typeof target === "string" ? (target === "#top" ? 0 : $(target)) : target;
    if (el === null) return;
    if (lenis) lenis.scrollTo(el, { duration: 1.4, immediate, force: true, offset: el === 0 ? 0 : -24 });
    else if (el === 0) window.scrollTo({ top: 0, behavior: immediate ? "auto" : "smooth" });
    else el.scrollIntoView({ behavior: immediate ? "auto" : "smooth" });
  };

  /* ---------- Every page opens at the top ----------
     Some viewers (and the back button) put a new page at the old page's scroll
     position. Unless the link points at a section (#id), pin the page to the top
     until the visitor scrolls themselves. */
  const deepLink = location.hash && $(location.hash);
  let visitorMoved = false;
  ["wheel", "touchstart", "keydown", "pointerdown"].forEach((ev) =>
    window.addEventListener(ev, () => (visitorMoved = true), { once: true, passive: true })
  );
  const pinTop = () => {
    if (deepLink || visitorMoved || window.scrollY === 0) return;
    window.scrollTo(0, 0);
    lenis?.scrollTo(0, { immediate: true, force: true });
  };
  pinTop();
  window.addEventListener("load", pinTop);
  [60, 250, 700, 1200, 1800].forEach((ms) => setTimeout(pinTop, ms));

  /* ---------- Hero word rotator ---------- */
  const rotator = $("[data-rotator]");
  let rotatorWords = [];
  if (rotator) {
    rotatorWords = $$(".rotator__w", rotator);
    gsap.set(rotator, { width: rotatorWords[0].offsetWidth });
    rotatorWords.forEach((w, i) => gsap.set(w, { yPercent: i ? 105 : 0 }));
    rotator.classList.add("is-init");
  }
  function startRotator() {
    if (!rotator) return;
    let i = 0;
    const fit = () => gsap.set(rotator, { width: rotatorWords[i].offsetWidth });
    fit();
    document.fonts?.ready.then(fit);
    window.addEventListener("resize", fit);
    if (reduce) return;
    setInterval(() => {
      if (document.hidden || motionPaused) return;
      const prev = rotatorWords[i];
      i = (i + 1) % rotatorWords.length;
      const next = rotatorWords[i];
      gsap.to(prev, { yPercent: -105, duration: 0.8, ease: "power3.inOut" });
      gsap.fromTo(next, { yPercent: 105 }, { yPercent: 0, duration: 0.8, ease: "power3.inOut" });
      gsap.to(rotator, { width: next.offsetWidth, duration: 0.8, ease: "power3.inOut" });
    }, 2600);
  }

  /* ---------- Page intro (no loading screen) ----------
     Runs before anything else is wired up, so the page always reveals itself. */
  const isHome = body.classList.contains("page-home");
  const curtain = $(".curtain");
  const arriving = root.classList.contains("arriving");
  gsap.set(curtain, { y: 0, yPercent: arriving && !reduce ? 0 : 100 }); // GSAP owns the panel's position from here

  function pageIntro() {
    const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
    if (isHome) {
      tl.from(".hero__frame", { scale: 1.08, duration: 2, ease: "power3.out" }, 0)
        .from(".hero__title .w > span, .rotator__w.is-on", { yPercent: 105, duration: 1.1, stagger: 0.06 }, 0.1);
    } else {
      if ($("[data-cover]")) tl.from("[data-cover]", { scale: 1.14, duration: 2.2, ease: "power3.out" }, 0);
      tl.from("[data-intro-title] .w > span", { yPercent: 105, duration: 1.1, stagger: 0.05 }, 0.05);
      if ($("[data-phero-media]")) {
        tl.from("[data-phero-media]", { clipPath: "inset(18% 0% 0% 0%)", autoAlpha: 0, duration: 1.4, ease: "power3.out" }, 0.25);
      }
    }
    tl.from("[data-intro-fade]", { y: 16, autoAlpha: 0, duration: 0.9, stagger: 0.06 }, 0.35)
      .from(".nav", { autoAlpha: 0, duration: 0.8, ease: "power2.out" }, 0.2);
  }

  function begin() {
    safe("intro", () => { if (!reduce) pageIntro(); });
    root.classList.add("ready"); // from-states are set: safe to show
    if (arriving) {
      root.classList.remove("arriving");
      if (!reduce) gsap.fromTo(curtain, { y: 0, yPercent: 0 }, { yPercent: -100, duration: 0.75, ease: "power3.inOut", onComplete: () => gsap.set(curtain, { yPercent: 100 }) });
    }
    window.__muReady = true;
    safe("rotator", startRotator);
    if (deepLink) setTimeout(() => scrollTo(location.hash, true), 60);
  }
  begin();

  /* ---------- Menu ---------- */
  const burger = $(".nav__burger");
  const burgerLabel = $("span", burger);
  const menu = $(".menu");
  function closeMenu() {
    if (!body.classList.contains("menu-open")) return;
    body.classList.remove("menu-open");
    burgerLabel.textContent = "Menu";
    burger.setAttribute("aria-expanded", "false");
    menu.setAttribute("aria-hidden", "true");
    lenis?.start();
    burger.focus({ preventScroll: true });
  }
  burger.addEventListener("click", () => {
    if (body.classList.contains("menu-open")) return closeMenu();
    body.classList.add("menu-open");
    burgerLabel.textContent = "Close";
    burger.setAttribute("aria-expanded", "true");
    menu.setAttribute("aria-hidden", "false");
    lenis?.stop();
    $(".menu__close", menu).focus({ preventScroll: true });
  });
  // close with the round button, a tap outside the card, or Esc
  $$("[data-menu-close]", menu).forEach((el) => el.addEventListener("click", closeMenu));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeMenu(); });

  /* ---------- Links: in-page anchors + page transitions ---------- */
  let leaving = false;
  const resetLeave = () => {
    leaving = false;
    curtain.classList.remove("is-active");
    gsap.killTweensOf(curtain);
    gsap.set(curtain, { yPercent: 100 });
    lenis?.start();
  };

  document.addEventListener("click", (e) => {
    const a = e.target.closest("a[href]");
    if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const href = a.getAttribute("href");
    if (a.target === "_blank" || /^(mailto:|tel:)/.test(href)) return;

    if (href.startsWith("#")) {
      if (href.length > 1 && href !== "#top" && !$(href)) return;
      e.preventDefault();
      closeMenu();
      scrollTo(href);
      // skip link: move keyboard focus into the content, not just the view
      if (href === "#main") $("#main").focus({ preventScroll: true });
      return;
    }

    const url = new URL(a.href, location.href);
    if (url.origin !== location.origin && location.protocol !== "file:") return;
    if (url.pathname === location.pathname) {
      e.preventDefault();
      closeMenu();
      scrollTo(url.hash && $(url.hash) ? url.hash : 0);
      return;
    }

    // Another page: the click is NOT held back, so the browser starts loading it
    // right away. The panel slides up over the old page while the new one loads,
    // and the next page lifts it on arrival.
    try { sessionStorage.setItem("mu-nav", "1"); } catch (err) { /* no storage: next page just won't animate in */ }
    if (reduce || leaving) return;
    leaving = true;
    curtain.classList.add("is-active");
    gsap.fromTo(curtain, { y: 0, yPercent: 100 }, { yPercent: 0, duration: 0.45, ease: "power3.out" });
    // if the browser didn't leave after all (a blocked or cancelled navigation), give the page back
    setTimeout(() => { if (leaving && document.visibilityState === "visible") resetLeave(); }, 3000);
  });

  // back/forward cache: the page comes back exactly as it was left, so undo the exit state
  window.addEventListener("pageshow", (e) => {
    if (!e.persisted) return;
    resetLeave();
    body.classList.remove("menu-open");
    burgerLabel.textContent = "Menu";
    burger.setAttribute("aria-expanded", "false");
    menu.setAttribute("aria-hidden", "true");
  });

  /* ---------- Nav state ---------- */
  const nav = $(".nav");
  let navIdle;
  ScrollTrigger.create({
    start: 0,
    end: "max",
    onUpdate: (self) => {
      const y = self.scroll();
      nav.classList.toggle("is-scrolled", y > 40);
      nav.classList.toggle("is-hidden", self.direction === 1 && y > window.innerHeight * 0.8 && !body.classList.contains("menu-open"));
      // once the visitor stops scrolling, bring the header (and its button) back
      clearTimeout(navIdle);
      navIdle = setTimeout(() => nav.classList.remove("is-hidden"), 450);
    },
  });

  /* ---------- Buttons: rolling letters, ink fill from the pointer, magnetic pull ---------- */
  $$(".btn").forEach((btn) => {
    const label = $(".btn__label", btn);
    if (label) {
      const text = label.textContent;
      btn.setAttribute("aria-label", text);
      label.setAttribute("aria-hidden", "true");
      label.innerHTML = [...text].map((c, i) => `<span class="ch" style="--i:${i}"><span>${c}</span><span>${c}</span></span>`).join("");
    }
    const fill = $(".btn__fill", btn);
    if (!fill) return;
    const size = () => btn.style.setProperty("--d", `${Math.hypot(btn.offsetWidth, btn.offsetHeight) * 2.2}px`);
    size();
    window.addEventListener("resize", size);
    const at = (e) => {
      const r = btn.getBoundingClientRect();
      btn.style.setProperty("--x", `${e.clientX - r.left}px`);
      btn.style.setProperty("--y", `${e.clientY - r.top}px`);
    };
    btn.addEventListener("pointerenter", at);
    btn.addEventListener("pointerleave", at);
    if (finePointer && !reduce) {
      const mx = gsap.quickTo(btn, "x", { duration: 0.5, ease: "power3" });
      const my = gsap.quickTo(btn, "y", { duration: 0.5, ease: "power3" });
      btn.addEventListener("pointermove", (e) => {
        const r = btn.getBoundingClientRect();
        mx((e.clientX - r.left - r.width / 2) * 0.22);
        my((e.clientY - r.top - r.height / 2) * 0.35);
      });
      btn.addEventListener("pointerleave", () => {
        gsap.to(btn, { x: 0, y: 0, duration: 0.9, ease: "elastic.out(1, 0.35)", overwrite: true });
      });
    }
  });

  /* ---------- Videos only play while on screen ---------- */
  $$("video").forEach((v) => {
    // the Home video is the page background, so it keeps playing (unless paused by the visitor)
    if (v.closest(".page-home .hero__frame")) return;
    ScrollTrigger.create({
      trigger: v.parentElement,
      start: "top bottom",
      end: "bottom top",
      onToggle: (st) => (st.isActive && !motionPaused ? v.play().catch(() => {}) : v.pause()),
    });
  });

  /* ---------- Home video: make sure it really plays on iPhones ---------- */
  safe("hero video", () => {
    const v = $(".page-home .hero__video");
    if (!v) return;
    v.muted = true;
    v.defaultMuted = true;
    const play = () => { if (!motionPaused && !document.hidden) v.play().catch(() => {}); };
    play();
    // Low Power Mode blocks autoplay until the visitor first touches or scrolls the page
    ["touchstart", "pointerdown", "scroll"].forEach((ev) =>
      window.addEventListener(ev, () => { if (v.paused) play(); }, { once: true, passive: true }));
    // (the fallback for hosts without byte-range support runs inline, right after the <video> tag)
  });

  /* ---------- Lightbox (work page) ---------- */
  const lbItems = $$("[data-lightbox]");
  if (lbItems.length) {
    const lb = $(".lightbox");
    const lbImg = $("img", lb);
    const lbCap = $("figcaption", lb);
    let current = 0;
    const show = (i) => {
      current = (i + lbItems.length) % lbItems.length;
      const card = lbItems[current];
      const img = $("img", card);
      lbImg.src = img.src;
      lbImg.alt = img.alt;
      lbCap.textContent = `${$("b", card).textContent} · ${$(".cap span", card).textContent}`;
    };
    const open = (i) => {
      show(i);
      lb.classList.add("is-open");
      lb.setAttribute("aria-hidden", "false");
      lenis?.stop();
      $(".lightbox__close").focus();
    };
    const close = () => {
      lb.classList.remove("is-open");
      lb.setAttribute("aria-hidden", "true");
      lenis?.start();
      lbItems[current].focus({ preventScroll: true });
    };
    lbItems.forEach((card, i) => {
      card.addEventListener("click", () => open(i));
      card.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(i); } });
    });
    $(".lightbox__close").addEventListener("click", close);
    $(".lightbox__prev").addEventListener("click", () => show(current - 1));
    $(".lightbox__next").addEventListener("click", () => show(current + 1));
    lb.addEventListener("click", (e) => { if (e.target === lb || e.target.tagName === "FIGURE") close(); });
    document.addEventListener("keydown", (e) => {
      if (!lb.classList.contains("is-open")) return;
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") show(current - 1);
      if (e.key === "ArrowRight") show(current + 1);
    });
  }

  /* ---------- Contact map: load Google Maps only on tap (saves ~2 MB) ---------- */
  $$("[data-map]").forEach((map) => {
    $(".map__load", map).addEventListener("click", () => {
      const frame = document.createElement("iframe");
      frame.title = "Map: 100 King Street West, Toronto";
      frame.src = map.dataset.map;
      frame.referrerPolicy = "no-referrer-when-downgrade";
      map.append(frame);
      map.classList.add("is-live");
    });
  });


  /* ---------- Services page: sticky image follows the section in view ---------- */
  const blocks = $$(".sblock");
  if (blocks.length) {
    const now = $("[data-now]");
    const setActive = (b, i) => {
      $$(".slist__frame img").forEach((im) => im.classList.toggle("is-on", im.dataset.for === b.id));
      if (now) now.textContent = b.dataset.name;
    };
    blocks.forEach((b, i) =>
      ScrollTrigger.create({
        trigger: b, start: "top 55%", end: "bottom 55%",
        onToggle: (st) => st.isActive && setActive(b, i),
      })
    );
  }

  /* ---------- Services on phones: swipeable cards (counter + deep links) ---------- */
  const track = $(".slist__blocks");
  if (track && matchMedia("(max-width: 760px)").matches) {
    const cards = $$(".sblock", track);
    const counter = $("[data-swipe-count]");
    // which card is mostly in view (no scroll listener needed)
    const seen = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (!en.isIntersecting) return;
        counter.textContent = `0${cards.indexOf(en.target) + 1} / 0${cards.length}`;
        $$(".slist__chips a").forEach((c) => c.classList.toggle("is-on", c.dataset.chip === en.target.id));
      });
    }, { root: track, threshold: 0.6 });
    cards.forEach((c) => seen.observe(c));
    $$(".slist__chips a").forEach((chip) => chip.addEventListener("click", (e) => {
      const card = $("#" + chip.dataset.chip);
      if (!card) return;
      e.preventDefault(); // handled here: slide the cards sideways instead of scrolling the page
      track.scrollTo({ left: card.offsetLeft - track.offsetLeft, behavior: reduce ? "auto" : "smooth" });
      chip.scrollIntoView({ block: "nearest", inline: "center", behavior: reduce ? "auto" : "smooth" });
    }));
    // a link to one service (e.g. services.html#kitchens): open on that card
    if (deepLink && track.contains(deepLink)) {
      track.scrollLeft = deepLink.offsetLeft - track.offsetLeft;
    }
  }

  if (reduce) return; // everything below is scroll motion only

  /* ---------- Home: the video stays as the page background; it dims as you scroll ---------- */
  if (isHome) {
    gsap.timeline({ scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: true } })
      .fromTo(".hero__dim", { opacity: 0 }, { opacity: 0.82, ease: "none" }, 0)
      .to(".hero__video", { scale: 1.06, ease: "none" }, 0)
      .to(".hero__inner", { yPercent: -14, autoAlpha: 0, ease: "none" }, 0);
  }

  /* ---------- Image parallax ---------- */
  $$("[data-phero-media] > img, [data-phero-media] > video, [data-parallax]").forEach((m) => {
    gsap.fromTo(m, { yPercent: -15 }, {
      yPercent: 0, ease: "none",
      scrollTrigger: { trigger: m.parentElement, start: "top bottom", end: "bottom top", scrub: true },
    });
  });

  /* ---------- Headings rise line by line ---------- */
  $$(".h2, .sblock__t, .footer__big").forEach((h) => {
    const words = $$(".w > span", h);
    gsap.from(words.length ? words : h, {
      yPercent: words.length ? 105 : 0, y: words.length ? 0 : 30, autoAlpha: words.length ? 1 : 0,
      duration: 1.1, ease: "power4.out", stagger: 0.04,
      scrollTrigger: { trigger: h, start: "top 88%" },
    });
  });
  $$(".sec .label, .pillar, .card, .next-band, .promise .link-arrow, .area__lead, .sblock__p, .sblock__list li, .checks li, .info > div, .map, .form > *, .split-sec .btn, .footer__sub, .fcol")
    .forEach((el) => {
      gsap.from(el, {
        y: 24, opacity: 0, duration: 0.9, ease: "power3.out",
        scrollTrigger: { trigger: el, start: "top 92%" },
      });
    });

  /* ---------- Photos wipe in as they arrive ---------- */
  $$(".card__img, .sblock__img, .split-sec__img").forEach((box) => {
    const img = $("img", box);
    gsap.timeline({ scrollTrigger: { trigger: box, start: "top 96%" } })
      .fromTo(box, { clipPath: "inset(100% 0% 0% 0%)" }, { clipPath: "inset(0% 0% 0% 0%)", duration: 1.1, ease: "power3.out" }, 0)
      .from(img, { scale: 1.22, duration: 1.6, ease: "power3.out" }, 0);
  });
  gsap.from(".footer__word", {
    yPercent: 40, opacity: 0, ease: "none",
    scrollTrigger: { trigger: ".footer__word", start: "top bottom", end: "bottom bottom", scrub: true },
  });

  /* ---------- Scroll-filled paragraphs ---------- */
  $$("[data-words]").forEach((p) => {
    gsap.to($$(".word", p), {
      opacity: 1, stagger: 0.1, ease: "none",
      scrollTrigger: { trigger: p, start: "top 80%", end: "bottom 50%", scrub: true },
    });
  });



  /* ---------- Process: gold lines draw in ---------- */
  $$(".step").forEach((s, i) => {
    gsap.fromTo(s, { "--p": 0 }, {
      "--p": 1, ease: "none",
      scrollTrigger: { trigger: s, start: "top 85%", end: "top 55%", scrub: true },
    });
    gsap.from($$(".step__n, .step__t, .step__p", s), {
      y: 20, opacity: 0, duration: 0.9, ease: "power3.out", stagger: 0.06,
      scrollTrigger: { trigger: s, start: "top 88%" },
    });
  });


  window.addEventListener("load", () => ScrollTrigger.refresh());
})();

/* ---------- Quote form (contact page; works without motion too) ---------- */
(() => {
  const form = document.querySelector("[data-form]");
  if (!form) return;
  const note = document.querySelector("[data-form-note]");

  const done = document.querySelector("[data-form-done]");
  const live = !/YOUR_FORM_ID/.test(form.action); // Formspree ID filled in?

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!form.reportValidity() || form.classList.contains("is-sending")) return;
    const d = new FormData(form);
    const projects = d.getAll("project").join(", ") || "Not specified";

    if (live) {
      // send to Formspree and stay on the page
      d.delete("project"); d.set("project", projects);
      d.set("_subject", `Quote request: ${projects}${d.get("name") ? " from " + d.get("name") : ""}`);
      note.classList.remove("is-error");
      note.textContent = "Sending…";
      form.classList.add("is-sending");
      try {
        const res = await fetch(form.action, { method: "POST", body: d, headers: { Accept: "application/json" } });
        if (!res.ok) throw new Error(res.status);
        const name = (d.get("name") || "").trim().split(/\s+/)[0];
        done.querySelector("[data-form-name]").textContent = name ? `, ${name}` : "";
        form.reset();
        form.classList.add("is-sent");
        done.hidden = false;
        done.focus({ preventScroll: true });
        note.textContent = "";
        if (form.getBoundingClientRect().top < 110) {
          if (window.__muScrollTo) window.__muScrollTo(form); else form.scrollIntoView({ behavior: "smooth" });
        }
      } catch (err) {
        note.classList.add("is-error");
        note.textContent = "That didn't go through. Please try again, or call us at 437-907-4710.";
      } finally {
        form.classList.remove("is-sending");
      }
      return;
    }

    // no Formspree ID yet: fall back to the visitor's email app
    const body = [
      `Name: ${d.get("name") || ""}`,
      `Email: ${d.get("email")}`,
      `Phone: ${d.get("phone") || ""}`,
      `Address: ${d.get("address") || ""}`,
      `Project: ${projects}`,
      "",
      d.get("message") || "",
    ].join("\n");
    const subject = `Free quote request: ${projects}`;
    window.location.href = `mailto:info@maxwell-urban.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    note.textContent = "Opening your email app. If nothing happens, call us at 437-907-4710.";
  });
})();
