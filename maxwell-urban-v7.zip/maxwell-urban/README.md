# Maxwell Urban Contracting — website

Static multi-page site: Home, Services, Work, About, Contact, plus a Privacy policy page (linked in the footer and under the form).

Run it through any web server (e.g. `npx serve .`) or upload the whole folder to Netlify / Vercel / any host.
Keep the folder together: the pages need `styles.css`, `main.js`, `vendor/`, `fonts/` and `assets/` next to them.

- `*.html` — the five pages (shared header/footer)
- `styles.css` — design (colors are the CSS variables at the top)
- `main.js` — page intro, page transitions and scroll animation (GSAP + ScrollTrigger, Lenis; bundled in `vendor/`, CDN fallback)
- `assets/` — logo, photos (WebP, 800px and 1600px), videos (`-sm` for phones, `-lg` for larger screens)
- `fonts/` — Schibsted Grotesk (a Google Font), served from the site's own folder (Latin subset) so it loads faster; the only typeface on the site

Layout: one 12-column grid. Section labels sit in columns 1–3, headings and content start at column 4.
Style rules:
- Square corners throughout (to match the angular logo). The one exception is the header's "Let's work together" button, which is a pill on purpose.
- One contact label everywhere: "Let's work together". The form's submit button says "Send my request".
- Section labels are rationed (at most one per three sections), with no decorative dots and no numbering.
- No em or en dashes in visible text; use a hyphen or "to".
- Dark theme only, by brand choice (black and gold).

Pages are kept light: phones get smaller photos and videos, and the contact map only loads when tapped.
There is no loading screen: pages show straight away, and moving between pages uses a short panel wipe.
Every page opens at the top, except links to a specific section (e.g. `services.html#kitchens`).

Search and sharing: each page has a canonical URL and absolute link-preview image on https://maxwell-urban.com,
Home and Contact carry LocalBusiness (GeneralContractor) structured data, and `robots.txt` / `sitemap.xml` sit at the root.
If the site moves to a different domain, update `SITE` in the generator (or search-and-replace the domain).

Before launch:
- Confirm the official phone number (site: 437-907-4710, van: 1-855-260-9898). The structured data and every tel link use 437.
- Have the privacy policy (`privacy.html`) reviewed, and confirm its details match how the business works: the two-year deletion period for requests that don't go ahead, and where form messages are stored once a form service is chosen.
- Finish the Formspree setup (see "Quote form" below). Until the form ID is filled in, the form falls back to opening the visitor's email app.
- Images: `ai-*.webp` are AI-generated concept images (Higgsfield, GPT Image 2.6), made for this site. They are not photos
  of Maxwell's jobs, so the Work page says so. Swap in real project photos when available (same names, 800 and 1600 px wide).
  The home hero reel (`hero-reel-*.mp4`) is cut from Mixkit clips (free licence). `g1` is the company's own van.

## Quote form (Formspree)

The form on `contact.html` posts to Formspree. With JavaScript it sends in the background and shows a thank-you note on the page; without JavaScript it does a normal post to Formspree.

1. Create a free account at formspree.io and add a new form. Have submissions sent to info@maxwell-urban.com.
2. Copy the form ID: the part after `/f/` in the endpoint (`https://formspree.io/f/abcdwxyz` → `abcdwxyz`).
3. In `contact.html`, replace `YOUR_FORM_ID` in the form's `action` with that ID (or set `FORMSPREE_ID` in the build script and rebuild).
4. Send a test from the live site, then confirm the first submission from the email Formspree sends.

What each email contains: name, email (replies go straight to the visitor), phone, project address, the project types ticked, and the message. The subject line reads like "Quote request: Kitchen, Bathroom from Jordan Lee". A hidden `_gotcha` field catches basic spam bots.

The free plan covers 50 submissions a month. In the Formspree dashboard you can also restrict the form to the site's domain and turn on extra spam filtering.
